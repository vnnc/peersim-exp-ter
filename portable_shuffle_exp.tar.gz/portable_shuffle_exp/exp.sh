#!/bin/bash
START_PARAM=1
END_PARAM=30
BASE_CYCLES=60000
for i in `seq $START_PARAM $END_PARAM`
do
	perl -pi.lock -e "s/shuffleInterval\s(.*)/shuffleInterval $i/" configs/cyclon.conf
	CYCLES=$(($BASE_CYCLES*$i))
	perl -pi.lock -e "s/^CYCLES\s([0-9]*)/CYCLES $CYCLES/" configs/cyclon.conf
	java -Xmx10g -jar starting-peersim.jar --config configs/cyclon.conf
done

